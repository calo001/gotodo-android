package com.github.calo001.gotodo.task

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.github.calo001.gotodo.R

class TasksActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tasks)
    }
}

package com.github.calo001.gotodo.login

interface LoginView {
    fun showProgress()
    fun hidePRogress()
    fun onSuccess()
    fun onError(error: String)
}